// Problem 9 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 9";
    return 0;
}