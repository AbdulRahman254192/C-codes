// Problem 7 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 7";
    return 0;
}