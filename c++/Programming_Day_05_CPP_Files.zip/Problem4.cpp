// Problem 4 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 4";
    return 0;
}