// Problem 1 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 1";
    return 0;
}