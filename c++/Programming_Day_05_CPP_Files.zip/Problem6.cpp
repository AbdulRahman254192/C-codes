// Problem 6 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 6";
    return 0;
}