// Problem 8 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 8";
    return 0;
}