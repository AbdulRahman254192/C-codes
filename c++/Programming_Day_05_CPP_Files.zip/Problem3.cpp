// Problem 3 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 3";
    return 0;
}