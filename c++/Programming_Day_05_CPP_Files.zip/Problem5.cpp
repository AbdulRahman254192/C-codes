// Problem 5 C++ program
#include <iostream>
using namespace std;
int main() {
    cout << "Problem 5";
    return 0;
}